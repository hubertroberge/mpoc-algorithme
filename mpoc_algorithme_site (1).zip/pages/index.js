import Head from 'next/head'
import TraitementMPOC from '../components/TraitementMPOC'

export default function Home() {
  return (
    <>
      <Head>
        <title>Algorithme MPOC</title>
      </Head>
      <main>
        <TraitementMPOC />
      </main>
    </>
  )
}
