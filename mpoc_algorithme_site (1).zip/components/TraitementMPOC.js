import { useState } from 'react';

const data = {
  AMLA: [
    {
      nom: "Spiriva® (Tiotropium)",
      dispositif: "Respimat ou HandiHaler",
      optimisation: [
        "Changer d'AMLA : Incruse®, Seebri®, Tudorza®",
        "Passer à AMLA + BALA : Spiolto®, Anoro®, Ultibro®",
        "Si symptômes persistants : Trelegy®, Enerzair® (RAMQ RE384)"
      ]
    },
    {
      nom: "Incruse® Ellipta",
      dispositif: "Ellipta",
      optimisation: [
        "Changer d'AMLA : Spiriva®, Seebri®, Tudorza®",
        "Passer à AMLA + BALA : Anoro®, Spiolto®, Ultibro®",
        "Trithérapie : Trelegy®, Enerzair® (RAMQ RE384)"
      ]
    },
    {
      nom: "Tudorza® Genuair",
      dispositif: "Genuair",
      optimisation: [
        "Changer d'AMLA : Spiriva®, Incruse®, Seebri®",
        "Passer à AMLA + BALA : Anoro®, Spiolto®, Ultibro®",
        "Trithérapie : Trelegy®, Enerzair® (RAMQ RE384)"
      ]
    },
    {
      nom: "Seebri® Breezhaler",
      dispositif: "Breezhaler",
      optimisation: [
        "Changer d'AMLA : Spiriva®, Incruse®, Tudorza®",
        "Passer à AMLA + BALA : Ultibro®, Anoro®, Spiolto®",
        "Trithérapie : Enerzair® (RAMQ RE384)"
      ]
    }
  ]
};

export default function TraitementMPOC() {
  const [categorie] = useState("AMLA");

  return (
    <div style={{ padding: '2rem' }}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Algorithme de traitement - MPOC</h1>
      <div style={{ marginTop: '2rem' }}>
        {data[categorie].map((med, index) => (
          <div key={index} style={{ border: '1px solid #ddd', borderRadius: '8px', padding: '1rem', marginBottom: '1rem' }}>
            <h2 style={{ fontSize: '1.2rem', fontWeight: '600' }}>{med.nom}</h2>
            <p style={{ fontStyle: 'italic' }}>Dispositif : {med.dispositif}</p>
            <ul>
              {med.optimisation.map((opt, i) => (
                <li key={i}>{opt}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
